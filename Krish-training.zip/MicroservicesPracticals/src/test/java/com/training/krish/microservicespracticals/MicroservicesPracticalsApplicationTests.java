package com.training.krish.microservicespracticals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesPracticalsApplicationTests {

    @Test
    void contextLoads() {
    }

}
